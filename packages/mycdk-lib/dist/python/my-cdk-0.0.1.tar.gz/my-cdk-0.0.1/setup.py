import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "my-cdk",
    "version": "0.0.1",
    "description": "mycdk",
    "license": "UNLICENSED",
    "url": "https://github.com/",
    "long_description_content_type": "text/markdown",
    "author": "Lalit",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "my_cdk",
        "my_cdk._jsii"
    ],
    "package_data": {
        "my_cdk._jsii": [
            "mycdk@0.0.1.jsii.tgz"
        ],
        "my_cdk": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.7",
    "install_requires": [
        "aws-cdk-lib>=2.62.1, <3.0.0",
        "constructs>=10.1.232, <11.0.0",
        "jsii>=1.85.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard~=2.13.3"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
